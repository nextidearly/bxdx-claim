import Airdrop from '../components/Airdrop'

export default function Home() {
  return (
    <>
      <Airdrop />
    </>
  )
}
