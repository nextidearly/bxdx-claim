"use client";

import React, { useState } from "react";
import Head from "next/head";
import { Container, Nav, Navbar } from "react-bootstrap";
import useWindowSize from "react-use/lib/useWindowSize";
import Confetti from "react-confetti";

export default function Airdrop() {
  const [address, setAddress] = useState("");
  const [amount, setAmount] = useState(0);
  const [checking, setChecking] = useState(false);
  const [checked, setChecked] = useState(false);
  const { width, height } = useWindowSize();

  const handleChangeAddress = (address) => {
    ``;
    if (!address) {
      setChecked(false);
      setAmount(0);
    }
    setAddress(address);
  };

  // Helper function to sleep for a specified duration
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  async function fetchAllData(address) {
    const baseUrl = "/tracker/priapi/v1/nft/personal/owned/collection-list";
    let allData = [];
    let pageNo = 1;
    let pageSize = 20; // Define page size as constant, since it's reused

    while (true) {
      const tParam = Date.now();
      const url = `${baseUrl}?t=${tParam}`;

      try {
        const res = await fetch(url, {
          headers: {
            "Content-Type": "application/json",
          },
          method: "POST",
          body: JSON.stringify({
            address: address,
            chain: 0,
            pageNo: pageNo,
            pageSize: pageSize,
            hiddenStatus: "",
            projectCertificated: false,
          }),
        });

        if (!res.ok) {
          throw new Error(`HTTP error! status: ${res.status}`);
        }

        const result = await res.json();
        allData = allData.concat(result.data.list);

        // Using the total and current fetched count to determine if there are more pages
        const fetchedItemsCount = pageNo * pageSize;
        if (fetchedItemsCount >= result.data.total) {
          // No more data to fetch, break out of the loop
          break;
        }

        pageNo++;

        // Sleep only if there is more data to fetch
        await sleep(200);
      } catch (error) {
        console.error("Error fetching data:", error);
        break; // Exit if there is an error
      }
    }

    console.log(`Fetched ${allData.length} items.`);
    return allData;
  }

  const checkEligibility = async (address) => {
    setChecked(false);
    if (!address) {
      setAmount(0);
      return;
    }

    setChecking(true);

    const data = await fetchAllData(address);
    const eligibleCollection = data.find(
      (collection) => collection.collectionName === "bitx-runes"
    );

    setAmount(eligibleCollection ? eligibleCollection.count : 0);
    setChecking(false);
    setChecked(true);
  };

  const truncateAddress = (address) => {
    return address.slice(0, 8) + "..." + address.substr(address.length - 5);
  };

  return (
    <>
      <Head>
        <title>Airdrop</title>
      </Head>
      <div className="main">
        <div className="nav-bar">
          <Navbar>
            <Container className="nav-container">
              <Navbar.Brand href="#home" className="logo">
                <img src="/logo.jpeg" alt="logo image" className="logo" />
              </Navbar.Brand>
              <Nav className="ml-auto">
                <Nav.Link href="https://bxdx.io" className="nav-item me-2">
                  Home
                </Nav.Link>
                <Nav.Link href="https://ido.bxdx.io" className="nav-item">
                  Presale
                </Nav.Link>
              </Nav>
            </Container>
          </Navbar>
        </div>

        <div className="gradient"></div>
        <div className="lines">
          <h1 className="bg-text">AIRDROP</h1>
        </div>

        <div className="presale-div">
          <div
            data-augmented-ui="tl-clip tr-clip br-clip bl-clip border inlay"
            className="card-main"
          >
            <>
              {" "}
              <div
                data-augmented-ui="tl-clip tr-clip br-clip bl-clip border inlay"
                className="input-grp"
              >
                <div className="input-head">
                  <span className="input-title">Enter your address</span>
                </div>

                <div className="input-group-inline">
                  <input
                    placeholder="Address"
                    type="numbers"
                    value={address}
                    onChange={(e) => handleChangeAddress(e.target.value)}
                  />
                </div>
              </div>
              <div className="info-group">
                <div className="sub-info">
                  <div className="info">Your address:</div>
                  <div
                    className={`${amount ? "text-green-500" : "text-white"}`}
                  >
                    {address ? <>{truncateAddress(address)}</> : <></>}
                  </div>
                </div>
                {checked && (
                  <>
                    {amount ? (
                      <>
                        <div className="sub-info">
                          <div className="info">OG PASS:</div>
                          <div>{amount}</div>
                        </div>
                        <div className="sub-info">
                          <div className="info">Allocation:</div>
                          <div>
                            <div className="flex">
                              {amount * 500}{" "}
                              <span className="text-sm">$BITX</span>
                            </div>
                          </div>
                        </div>
                        <div className="sub-info">
                          <div>
                            No further action is required from you , your
                            allocation will be airdropped to your wallet on 20 /
                            04 / 2024 ( Do not connect your wallet anywhere )
                          </div>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="sub-info">
                          <div>Your address is not registered.</div>
                        </div>
                      </>
                    )}
                  </>
                )}
              </div>
              <div className="button-group">
                <button
                  data-augmented-ui="tl-clip tr-clip br-clip bl-clip"
                  onClick={() => checkEligibility(address)}
                >
                  {checking ? "Checking..." : "Check eligibility"}
                </button>
              </div>
            </>
          </div>
        </div>
      </div>

      {checked && amount && <Confetti width={width} height={height} />}
    </>
  );
}
